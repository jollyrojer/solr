name             'file'
maintainer       'Jens Segers'
maintainer_email ''
license          ''
description      'Some handy Chef resources for when you want to replace text and lines in files.'
long_description IO.read(File.join(File.dirname(__FILE__), 'README.md'))
version          '2.0'
