name             'test'
maintainer       'test'
maintainer_email 'test@test.com'
license          ''
description      'Test the file cookbook'
long_description 'Test the file cookbook'
version          '1.0'

depends 'file'
