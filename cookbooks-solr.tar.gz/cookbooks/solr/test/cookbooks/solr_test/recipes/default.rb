include_recipe "tomcat-component"
include_recipe "solr"
include_recipe "minitest-handler"
