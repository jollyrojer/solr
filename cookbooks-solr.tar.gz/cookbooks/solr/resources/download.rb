actions :download_extract
attribute :solr_url, :kind_of => String
attribute :version,  :kind_of => String
attribute :solr_checksum,  :kind_of => String
