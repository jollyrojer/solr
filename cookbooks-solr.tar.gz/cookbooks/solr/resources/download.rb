actions :download_extract
attribute :url, :kind_of => String
attribute :version,  :kind_of => String
attribute :checksum,  :kind_of => String
