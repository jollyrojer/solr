name "solr_test"
version "0.1.0"

depends "solr", "0.1.0"
depends "minitest-handler"
