name "solr"
version "0.1.0"

depends "file", "2.0"
depends "java", "1.11.7"
depends "zookeeper-component", "0.1.0"
depends "tomcat-component", "0.1.0"
